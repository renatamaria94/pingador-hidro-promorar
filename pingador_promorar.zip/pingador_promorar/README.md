# Pingador automático para manter o app Promorar ativo

Este repositório usa GitHub Actions para enviar um ping ao seu app no Render a cada 10 minutos.

### Como usar:
1. Faça o upload deste repositório para o seu GitHub.
2. Vá em "Actions" e ative os workflows.
3. Pronto! O GitHub rodará o `pingador.py` a cada 10 minutos.

URL monitorada: https://promorar-hidro.onrender.com
